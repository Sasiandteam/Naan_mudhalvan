# NANMUDHALVAN_TUESDAYBATCH_PROJECT_FILES

PROJECT CREATED BY : SASIKUMAR V
au62202104083
paavai college of engineering


LOGIN DETAILS:


UNAME: admin1234


Password:Admin@45678




#Project Running steps:

python manage.py makemigrations

python manage.py migrate

python manage.py createsuperuser

python manage.py runserver
